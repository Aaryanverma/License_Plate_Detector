#!/usr/bin/env python
# coding: utf-8

# In[11]:


import numpy as np
import matplotlib.pyplot as plt
from PIL import Image, ImageFilter
import cv2
from os import listdir
from os.path import isfile, join
from imutils import contours
from keras.models import load_model
from flask import Flask, redirect, url_for, request, render_template, Response, jsonify, redirect
from werkzeug.utils import secure_filename
from gevent.pywsgi import WSGIServer
import os
import sys
from keras.preprocessing import image
import keras
import theano
from util import base64_to_pil
from keras.utils import CustomObjectScope
from keras.initializers import glorot_uniform

# charac=np.array(0)

# In[10]:
flask_app = Flask(__name__)
MODEL_PATH='/home/aaryanverma02/mysite/models/plate_model.h5'
with CustomObjectScope({'GlorotUniform': glorot_uniform()}):
        model = load_model(MODEL_PATH,compile=False)
model._make_predict_function()

@flask_app.route('/', methods=['GET'])
def index():
    # Main page
    return render_template('index.html')

# In[4]:

def roi(img):
    img3 = cv2.imread(img)
    #convert my image to grayscale
    gray = cv2.cvtColor(img3, cv2.COLOR_BGR2GRAY)
    #perform adaptive threshold so that I can extract proper contours from the image
    #need this to extract the name plate from the image.
    thresh = cv2.adaptiveThreshold(gray,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY,11,2)
    contours,h = cv2.findContours(thresh,1,2)

    #once I have the contours list, i need to find the contours which form rectangles.
    #the contours can be approximated to minimum polygons, polygons of size 4 are probably rectangles
    largest_rectangle = [0,0]
    for cnt in contours:
        approx = cv2.approxPolyDP(cnt,0.01*cv2.arcLength(cnt,True),True)
        if len(approx)==4: #polygons with 4 points is what I need.
            area = cv2.contourArea(cnt)
            if area > largest_rectangle[0]:
                #find the polygon which has the largest size.
                largest_rectangle = [cv2.contourArea(cnt), cnt, approx]

    x,y,w,h = cv2.boundingRect(largest_rectangle[1])
    #crop the rectangle to get the number plate.
    rr=img3[int(y):int(y+h),int(x):int(x+w)]
    #cv2.drawContours(img,[largest_rectangle[1]],0,(0,0,255),-1)
    # plt.imshow(roi, cmap = 'gray')
    # plt.show()
    return rr

# In[5]:


def find_contours(dimensions, img) :

    # Find all contours in the image
    cntrs, _ = cv2.findContours(img.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # Retrieve potential dimensions
    lower_width = dimensions[0]
    upper_width = dimensions[1]
    lower_height = dimensions[2]
    upper_height = dimensions[3]

    ii = cv2.imread('contour.jpg')
    # Check largest 5 or  15 contours for license plate or character respectively
    cntrs = sorted(cntrs, key=cv2.contourArea, reverse=True)[:15]

    x_cntr_list = []
    target_contours = []
    img_res = []
    for cntr in cntrs :
        #detects contour in binary image and returns the coordinates of rectangle enclosing it
        intX, intY, intWidth, intHeight = cv2.boundingRect(cntr)

        #checking the dimensions of the contour to filter out the characters by contour's size
        if intWidth > lower_width and intWidth < upper_width and intHeight > lower_height and intHeight < upper_height :
            x_cntr_list.append(intX) #stores the x coordinate of the character's contour, to used later for indexing the contours

            char_copy = np.zeros((44,24))
            #extracting each character using the enclosing rectangle's coordinates.
            char = img[intY:intY+intHeight, intX:intX+intWidth]
            char = cv2.resize(char, (20, 40))

            cv2.rectangle(ii, (intX,intY), (intWidth+intX, intY+intHeight), (50,21,200), 2)
#             plt.imshow(ii, cmap='gray')

            # Make result formatted for classification: invert colors
            char = cv2.subtract(255, char)

            # Resize the image to 24x44 with black border
            char_copy[2:42, 2:22] = char
            char_copy[0:2, :] = 0
            char_copy[:, 0:2] = 0
            char_copy[42:44, :] = 0
            char_copy[:, 22:24] = 0

            img_res.append(char_copy) #List that stores the character's binary image (unsorted)

    #Return characters on ascending order with respect to the x-coordinate (most-left character first)
#     plt.show()
    #arbitrary function that stores sorted list of character indeces
    indices = sorted(range(len(x_cntr_list)), key=lambda k: x_cntr_list[k])
    img_res_copy = []
    for idx in indices:
        img_res_copy.append(img_res[idx])# stores character images according to their index
    img_res = np.array(img_res_copy)

    return img_res


# In[6]:


def segment_characters(image) :

    # Preprocess cropped license plate image
    img = cv2.resize(image, (333, 75))
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, img_binary = cv2.threshold(img_gray, 200, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)
    img_erode = cv2.erode(img_binary, (3,3))
    img_dilate = cv2.dilate(img_erode, (3,3))

    LP_WIDTH = img_dilate.shape[0]
    LP_HEIGHT = img_dilate.shape[1]

    # Make borders white
    img_dilate[0:3,:] = 255
    img_dilate[:,0:3] = 255
    img_dilate[72:75,:] = 255
    img_dilate[:,330:333] = 255

    # Estimations of character contours sizes of cropped license plates
    dimensions = [LP_WIDTH/6, LP_WIDTH/2, LP_HEIGHT/10, 2*LP_HEIGHT/3]
#     plt.imshow(img_dilate, cmap='gray')
#     plt.show()
#     cv2.imwrite('contour.jpg',img_dilate)

    # Get contours within cropped license plate
    char_list = find_contours(dimensions, img_dilate)

    return char_list


# In[7]:


def fix_dimension(img):
    new_img = np.zeros((28,28,3))
    for i in range(3):
        new_img[:,:,i] = img
    return new_img

def show_results(char):
    dic = {}
    characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    for i,c in enumerate(characters):
        dic[i] = c

    output = []
    if len(char)!=0:
        for i,ch in enumerate(char): #iterating over the characters
            img_ = cv2.resize(ch, (28,28))
            img = fix_dimension(img_)
            img = img.reshape(1,28,28,3) #preparing image for the model
            y_ = model.predict_classes(img)[0] #predicting the class
            character = dic[y_] #
            output.append(character) #storing the result in a list
    else:
        output="Cannot see the number plate, use another image"

    plate_number = ''.join(output)

    return plate_number


# In[8]:
@flask_app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        # Get the image from post request
        img = base64_to_pil(request.json)


        # Save the image to ./uploads
        img.save("/home/aaryanverma02/mysite/uploads/image.jpg")
        rr=roi("/home/aaryanverma02/mysite/uploads/image.jpg")
        # Make prediction
        char = segment_characters(rr)

        result=""
        # Serialize the result, you can add additional fields
        result=show_results(char)

        return jsonify(result=result)



    return None


# if __name__ == '__main__':
#     # app.run(port=5002, threaded=False)
#     app.run(port=8080, threaded=False)
    # Serve the app with gevent
    # http_server = WSGIServer(('0.0.0.0', 5000), flask_app)
    # http_server.serve_forever()
×
